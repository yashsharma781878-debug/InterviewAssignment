import { LightningElement , wire } from 'lwc';
import getMostRecentAccount from '@salesforce/apex/DisplayRecentAccountController.getMostRecentAccount';

export default class DisplayRecentAccounts extends LightningElement {

    accountList=[];

    @wire(getMostRecentAccount)
    GetRecentAccounts(response){
        const{data , error}= response;
       
        if(error){
            console.error(error);
        }
        if(data){
            this.accountList = data;

            console.log('Account Data', this.accountList);
        }
    }

}